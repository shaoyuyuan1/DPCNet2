python -B main_SemanticKITTI.py --gpu 0 --mode test --test_area 11
python -B main_SemanticKITTI.py --gpu 0 --mode test --test_area 12
python -B main_SemanticKITTI.py --gpu 0 --mode test --test_area 13
python -B main_SemanticKITTI.py --gpu 0 --mode test --test_area 14
python -B main_SemanticKITTI.py --gpu 0 --mode test --test_area 15
python -B main_SemanticKITTI.py --gpu 0 --mode test --test_area 16
python -B main_SemanticKITTI.py --gpu 0 --mode test --test_area 17
python -B main_SemanticKITTI.py --gpu 0 --mode test --test_area 18
python -B main_SemanticKITTI.py --gpu 0 --mode test --test_area 19
python -B main_SemanticKITTI.py --gpu 0 --mode test --test_area 20
python -B main_SemanticKITTI.py --gpu 0 --mode test --test_area 21

